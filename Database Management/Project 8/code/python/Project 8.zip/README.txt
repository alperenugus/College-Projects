Name: Alperen UGUS
CWID: 10864101

Challenges: I think the only challenge was about the exception handling. pg8000 made some changes for the latest version, so I had to deal with exception messages.

Likes / Dislikes: It is a well prepared assignment to make practice for both SQL and using SQL in a GUI. 

How long: 
Approximately 2 hours.